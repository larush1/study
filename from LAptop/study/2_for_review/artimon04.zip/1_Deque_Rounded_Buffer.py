# ID 67198509
class Deque:
    def __init__(self, max_size):
        self.queue = [None] * max_size
        self.max_size = max_size
        self.head = 0
        self.tail = 0
        self.size = 0

    def push_back(self, x):
        if self.max_size != self.size:
            self.queue[(self.head - 1) % self.max_size] = x
            self.head = (self.head - 1) % self.max_size
            self.size += 1
        else:
            print('error')

    def push_front(self, x):
        if self.max_size != self.size:
            self.queue[self.tail] = x
            self.tail = (self.tail + 1) % self.max_size
            self.size += 1
        else:
            print('error')

    def pop_back(self):
        if self.size != 0:
            x = self.queue[(self.head)]
            self.queue[(self.head)] = None
            self.head = (self.head + 1) % self.max_size
            self.size -= 1
            print(x)
        else:
            print('error')

    def pop_front(self):
        if self.size != 0:
            x = self.queue[(self.tail - 1) % self.max_size]
            self.queue[(self.tail - 1) % self.max_size] = None
            self.tail = (self.tail - 1) % self.max_size
            self.size -= 1
            print(x)
        else:
            print('error')


def run():
    num_com = int(input())
    max_size = int(input())
    q = Deque(max_size)
    for _ in range(num_com):
        command = input().split()
        if command[0] == 'push_back':
            q.push_back(command[1])
        if command[0] == 'push_front':
            q.push_front(command[1])
        if command[0] == 'pop_back':
            q.pop_back()
        if command[0] == 'pop_front':
            q.pop_front()


if __name__ == '__main__':
    run()
